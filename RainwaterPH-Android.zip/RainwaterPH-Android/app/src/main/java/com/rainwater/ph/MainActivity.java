package com.rainwater.ph;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;

/**
 * Rainwater pH app: shows the dashboard served by the ESP32 in a full-screen view.
 * Tap the gear button to change the ESP32 address (default 192.168.4.1 = ESP32 hotspot).
 */
public class MainActivity extends Activity {

    private static final String PREFS = "settings";
    private static final String KEY_ADDR = "address";
    private static final String DEFAULT_ADDR = "192.168.4.1";

    private WebView web;
    private SharedPreferences prefs;
    private boolean dialogOpen = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#0F172A"));
        getWindow().setNavigationBarColor(Color.parseColor("#1E293B"));
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#0F172A"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0F172A"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.addJavascriptInterface(new Bridge(this), "Android");
        web.setWebChromeClient(new WebChromeClient());   // enables alert()/confirm() dialogs
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) showOffline();
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        // Small gear button (top-right) to change the ESP32 address
        TextView gear = new TextView(this);
        gear.setText("⚙");
        gear.setTextSize(20);
        gear.setTextColor(Color.WHITE);
        gear.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.parseColor("#AA334155"));
        gear.setBackground(bg);
        int size = dp(40);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size, Gravity.BOTTOM | Gravity.END);
        lp.setMargins(0, 0, dp(14), dp(80));
        gear.setOnClickListener(v -> askAddress());
        root.addView(gear, lp);

        setContentView(root);

        if (!prefs.contains(KEY_ADDR)) askAddress();
        else load();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private String address() {
        return prefs.getString(KEY_ADDR, DEFAULT_ADDR);
    }

    private void load() {
        String a = address().trim();
        if (!a.startsWith("http://") && !a.startsWith("https://")) a = "http://" + a;
        if (!a.endsWith("/")) a = a + "/";
        web.loadUrl(a);
    }

    private void askAddress() {
        if (dialogOpen) return;
        dialogOpen = true;
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setText(address());
        input.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this)
                .setTitle("ESP32 address")
                .setMessage("Enter the IP shown in the Arduino Serial Monitor (e.g. 192.168.1.50), "
                        + "or 192.168.4.1 if your phone is on the 'RainwaterPH' hotspot.")
                .setView(input)
                .setPositiveButton("Connect", (d, w) -> {
                    prefs.edit().putString(KEY_ADDR, input.getText().toString().trim()).apply();
                    load();
                })
                .setNegativeButton("Cancel", (d, w) -> { if (web.getUrl() == null) load(); })
                .setOnDismissListener(d -> dialogOpen = false)
                .show();
    }

    private void showOffline() {
        String html = "<html><body style='background:#0f172a;color:#e2e8f0;font-family:sans-serif;"
                + "padding:40px 24px;text-align:center'>"
                + "<div style='font-size:56px'>📡</div><h2>Can't reach the sensor</h2>"
                + "<p style='color:#94a3b8'>Tried <b>" + address() + "</b>.<br><br>"
                + "Check the ESP32 is powered and your phone is on the same Wi-Fi "
                + "(or the RainwaterPH hotspot).</p>"
                + "<button onclick='location.href=\"retry:\"' style='padding:14px 28px;border:0;"
                + "border-radius:12px;background:#2563eb;color:#fff;font-size:16px'>Retry</button>"
                + "<p style='color:#94a3b8;margin-top:24px'>Tap ⚙ to change the address.</p>"
                + "</body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                if ("retry".equals(req.getUrl().getScheme())) { restoreClient(); load(); return true; }
                return false;
            }
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) showOffline();
            }
        });
    }

    private void restoreClient() {
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) showOffline();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    /** Lets the dashboard vibrate the phone when pH goes out of the safe range. */
    static class Bridge {
        private final Context ctx;
        Bridge(Context c) { ctx = c; }

        @JavascriptInterface
        public void vibrate() {
            Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) return;
            long[] pattern = {0, 300, 150, 300};
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1));
            else v.vibrate(pattern, -1);
        }
    }
}
