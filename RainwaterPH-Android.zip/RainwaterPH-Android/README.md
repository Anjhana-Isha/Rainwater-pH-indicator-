# Rain pH – Android app

Full-screen Android app for the ESP32 rainwater pH monitor (`rainwater_ph_monitor.ino`).

## Get the APK without a computer (GitHub, from your phone)
1. Create a free account at github.com and tap **New repository** (name it `RainwaterPH`).
2. Tap **Add file → Upload files** and upload everything from this folder,
   keeping the folders (`app/…`, `.github/workflows/build.yml`). Tip: uploading the
   whole folder from a desktop browser is easiest; on a phone, use **Create new file**
   and type the path (e.g. `.github/workflows/build.yml`) then paste the contents.
3. Open the **Actions** tab. The "Build APK" job runs automatically (~3–4 min).
4. Open the finished run, download **RainwaterPH-apk** (a zip), unzip, tap `app-debug.apk`,
   and allow "Install unknown apps" when Android asks.

## Or build on a computer
Open this folder in Android Studio → Build → Build APK(s).

## Using the app
- First launch asks for the ESP32 address: the IP from the Arduino Serial Monitor,
  or `192.168.4.1` if your phone is joined to the `RainwaterPH` hotspot.
- The ⚙ button changes the address later.
- The phone vibrates when pH leaves the safe range (while the app is open).
